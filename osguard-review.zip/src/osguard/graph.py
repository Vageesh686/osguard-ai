"""LangGraph orchestration for the Supervisor and three specialist workflows."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any, Literal

from langgraph.graph import END, START, StateGraph

from osguard.agents._common import ModelProvider, create_model_provider
from osguard.agents.command_verify import create_command_verification_agent
from osguard.agents.compatibility import create_compatibility_agent
from osguard.agents.diagnostic import create_diagnostic_agent
from osguard.config import GroqSettings
from osguard.context import WindowsTool, create_evidence_collection_node
from osguard.repair.approval import create_approval_node
from osguard.repair.demo_cache import DEMO_TOOL_NAME, DemoCacheStore, is_exact_demo_request
from osguard.repair.eligibility import create_repair_planning_node
from osguard.repair.executor import ExecutionLedger, create_restricted_executor_node
from osguard.repair.validation import create_post_repair_validation_node
from osguard.schemas import (
    ApprovalState,
    FinalResponse,
    OSSubsystem,
    ProblemType,
    RequestIntent,
    SpecialistName,
    SpecialistResult,
    SupervisorClassification,
    RetrievalResult,
)
from osguard.state import OSGuardState
from osguard.supervisor import (
    SPECIALIST_ORDER,
    Classifier,
    create_supervisor_classifier,
    create_supervisor_node,
)
from osguard.verification.ieee import Assessor, create_ieee_verification_node
from osguard.verification.proposals import create_action_proposal_node


_SPECIALIST_NODES = {
    SpecialistName.DIAGNOSTIC: "diagnostic_agent",
    SpecialistName.COMMAND_VERIFICATION: "command_verification_agent",
    SpecialistName.COMPATIBILITY: "compatibility_agent",
}
SpecialistNode = Callable[[OSGuardState], dict[str, Any]]
EvidenceNode = Callable[[OSGuardState], dict[str, Any]]


def route_to_next_specialist(
    state: OSGuardState,
) -> Literal[
    "diagnostic_agent",
    "command_verification_agent",
    "compatibility_agent",
    "aggregate_findings",
]:
    """Route to each selected specialist at most once, even after partial errors."""
    classification = state.get("classification")
    if classification is None or classification.needs_clarification:
        return "aggregate_findings"

    completed = set(state.get("completed_specialists", []))
    selected = set(state.get("selected_specialists", []))
    for specialist in SPECIALIST_ORDER:
        if specialist in selected and specialist not in completed:
            return _SPECIALIST_NODES[specialist]  # type: ignore[return-value]
    return "aggregate_findings"


def aggregate_findings_node(state: OSGuardState) -> dict[str, str]:
    """Set status from completed specialist results without replacing their data."""
    classification = state.get("classification")
    results: list[SpecialistResult] = state.get("specialist_results", [])
    errors = state.get("errors", [])
    has_supervisor_error = any(error.stage == "supervisor" for error in errors)
    failed = any(result.status == "failed" for result in results)
    succeeded = any(result.status == "completed" for result in results)

    if has_supervisor_error:
        status = "classification_error"
    elif classification is not None and classification.needs_clarification:
        status = "needs_clarification"
    elif failed and succeeded:
        status = "partial_failure"
    elif failed:
        status = "specialist_failure"
    elif succeeded:
        status = "specialists_completed"
    else:
        status = "classification_complete"
    return {"workflow_status": status}


def _finding_summary(state: OSGuardState) -> str:
    symptoms = len(state.get("diagnostic_symptoms", []))
    observations = len(state.get("diagnostic_observations", []))
    hypotheses = len(state.get("diagnostic_hypotheses", []))
    command_findings = len(state.get("command_verification_findings", []))
    compatibility_findings = len(state.get("compatibility_findings", []))
    evidence_count = len(state.get("retrieved_evidence", []))
    successful_tools = sum(item.status == "success" for item in state.get("tool_results", []))
    steps = len(state.get("safe_diagnostic_steps", []))
    parts: list[str] = []
    if symptoms or observations or hypotheses:
        parts.append(
            f"diagnostic analysis: {symptoms} reported symptom(s), "
            f"{observations} quoted observation(s), {hypotheses} hypothesis/hypotheses"
        )
    if command_findings:
        parts.append(f"static command review: {command_findings} finding(s)")
    if compatibility_findings:
        parts.append(f"compatibility review: {compatibility_findings} finding(s)")
    if evidence_count:
        parts.append(f"documentation retrieval: {evidence_count} passage(s)")
    if successful_tools:
        parts.append(f"read-only system checks: {successful_tools} completed")
    if steps:
        parts.append(f"{steps} safe information-gathering step(s)")
    return "; ".join(parts) if parts else "no structured findings"


def final_response_node(state: OSGuardState) -> dict[str, FinalResponse]:
    """Build a concise response that reflects available and failed agent results."""
    classification: SupervisorClassification | None = state.get("classification")
    selected = list(state.get("selected_specialists", []))
    results: list[SpecialistResult] = state.get("specialist_results", [])
    errors = state.get("errors", [])
    actions = state.get("proposed_corrective_actions", [])
    verifications = state.get("ieee_verification_results", [])
    proposal_summary = state.get("action_proposal_result")
    eligibility = state.get("repair_eligibility")
    plan = state.get("repair_plan")
    approval = state.get("approval_state")
    execution = state.get("execution_result")
    validation = state.get("validation_result")
    status = state.get("workflow_status", "unknown")
    issue_category = (
        classification.problem_type if classification is not None else ProblemType.UNKNOWN
    )
    has_supervisor_error = any(error.stage == "supervisor" for error in errors)

    if has_supervisor_error:
        message = (
            "OSGuard could not classify this request reliably. No specialist analysis "
            "was started. Please restate the issue with its main symptom or command."
        )
    elif classification is not None and classification.needs_clarification:
        message = classification.clarification_question or (
            "Please provide more information about the Windows issue."
        )
        message += " No specialist analysis was started."
    elif results:
        specialist_labels = ", ".join(item.value for item in selected) or "none"
        message = (
            f"Classified as {issue_category.value}. Selected specialists: {specialist_labels}. "
            f"Available output: {_finding_summary(state)}. "
            "OSGuard used the supplied request, retrieved documentation, and the "
            "listed read-only checks."
        )
        if execution is None or execution.status == "not_started":
            message += " It did not execute commands or perform repairs."
        if any(result.status == "failed" for result in results):
            message += " One or more specialists failed; successful results were retained."
        if verifications:
            counts = {
                decision: sum(item.overall == decision for item in verifications)
                for decision in ("supported", "unsupported", "uncertain")
            }
            message += (
                " IEEE recommendation review: "
                f"{counts['supported']} supported, {counts['unsupported']} unsupported, "
                f"{counts['uncertain']} uncertain. These results do not authorize execution."
            )
        elif proposal_summary and proposal_summary.status == "no_action":
            message += " " + proposal_summary.message
    else:
        message = (
            f"Classified as {issue_category.value}, but no specialist was selected. "
            "No findings or recommendations are available."
        )
    if verifications:
        verification_by_id = {item.action_id: item for item in verifications}
        action_lines = [
            f"{action.description}: {verification_by_id[action.action_id].overall}"
            for action in actions[:5]
            if action.action_id in verification_by_id
        ]
        if action_lines:
            message += " Recommendations: " + "; ".join(action_lines) + "."
        missing = list(dict.fromkeys(
            item for verification in verifications for item in verification.missing_information
        ))
        if missing:
            message += " Additional information needed: " + "; ".join(missing[:4]) + "."
    if proposal_summary and proposal_summary.status in {"no_action", "failed"}:
        if proposal_summary.message and proposal_summary.message not in message:
            message += " " + proposal_summary.message
    ieee_summary = state.get("ieee_verification_summary")
    if ieee_summary and ieee_summary.status == "partial_failure":
        message += " One or more IEEE model assessments failed; affected checks remain uncertain."
    if plan is not None and eligibility and eligibility.status == "eligible":
        if approval and approval.status == "declined":
            message += " The exact demo-cache repair was declined; no repair ran."
        elif approval and approval.status == "expired":
            message += " Approval was missing, stale, or mismatched; no repair ran."
        elif approval and approval.status == "not_requested":
            message += " A checkpointed approval session is required before this plan can run."
        elif execution and execution.status == "succeeded":
            message += " The approved OSGuard demo-cache handler ran."
        elif execution and execution.status in {"failed", "blocked", "already_executed"}:
            message += f" Demo-cache execution status: {execution.status}."
    elif actions:
        message += " These actions remain recommendation only; no repair is eligible."
    if validation and validation.status != "not_started":
        message += f" Post-repair validation: {validation.status}. {validation.details}"

    finding_fields = (
        state.get("diagnostic_symptoms")
        or state.get("diagnostic_subsystems")
        or state.get("diagnostic_observations")
        or state.get("diagnostic_hypotheses")
        or state.get("safe_diagnostic_steps")
        or state.get("command_verification_findings")
        or state.get("compatibility_findings")
        or state.get("proposed_corrective_actions")
        or state.get("ieee_verification_results")
        or state.get("repair_plan")
        or (validation and validation.status != "not_started")
        or state.get("retrieved_evidence")
        or any(item.status == "success" for item in state.get("tool_results", []))
    )
    return {
        "final_response": FinalResponse(
            message=message,
            workflow_status=status,
            issue_category=issue_category,
            selected_specialists=selected,
            findings_available=bool(finding_fields),
        )
    }


def build_supervisor_graph(
    *,
    classifier: Classifier | None = None,
    settings: GroqSettings | None = None,
    model_factory: Callable[..., Any] | None = None,
    model: Any | None = None,
    specialist_nodes: Mapping[SpecialistName, SpecialistNode] | None = None,
    evidence_collection_node: EvidenceNode | None = None,
    retriever: Callable[..., RetrievalResult] | None = None,
    windows_tools: Mapping[str, WindowsTool] | None = None,
    action_proposer: Callable[[OSGuardState], Any] | None = None,
    ieee_assessor: Assessor | None = None,
    repair_store: DemoCacheStore | None = None,
    execution_ledger: ExecutionLedger | None = None,
    checkpointer: Any | None = None,
) -> Any:
    """Build the typed graph with one shared Groq model and injectable agents.

    The default path creates a single ChatGroq instance for classification and
    specialist structured outputs. Injected classifiers or specialist nodes
    keep graph orchestration testable without Groq credentials/network access.
    """
    model_provider: ModelProvider = create_model_provider(
        settings=settings,
        model_factory=model_factory,
        model=model,
    )
    active_classifier = classifier
    if active_classifier is None:
        live_classifier: Classifier | None = None

        def classify(request: str):
            nonlocal live_classifier
            if is_exact_demo_request(request):
                return SupervisorClassification(
                    intent=RequestIntent.DIAGNOSE,
                    problem_type=ProblemType.STORAGE,
                    os_subsystems=[OSSubsystem.STORAGE_FILESYSTEM],
                    selected_specialists=[SpecialistName.DIAGNOSTIC],
                    routing_rationale="Exact OSGuard demo-cache request; use the fixed local inspection.",
                )
            if live_classifier is None:
                live_classifier = create_supervisor_classifier(model=model_provider())
            return live_classifier(request)

        active_classifier = classify

    injected_nodes = specialist_nodes or {}
    diagnostic_node = injected_nodes.get(SpecialistName.DIAGNOSTIC)
    if diagnostic_node is None:
        live_diagnostic = create_diagnostic_agent(model_provider=model_provider)

        def diagnostic_node(state: OSGuardState) -> dict[str, Any]:
            if is_exact_demo_request(state.get("user_request", "")):
                return {
                    "specialist_results": [SpecialistResult(
                        specialist=SpecialistName.DIAGNOSTIC, status="completed",
                        message="The exact demo request was checked using the dedicated read-only cache inspection.",
                    )],
                    "completed_specialists": [SpecialistName.DIAGNOSTIC],
                }
            return live_diagnostic(state)
    command_node = injected_nodes.get(SpecialistName.COMMAND_VERIFICATION)
    if command_node is None:
        command_node = create_command_verification_agent(model_provider=model_provider)
    compatibility_node = injected_nodes.get(SpecialistName.COMPATIBILITY)
    if compatibility_node is None:
        compatibility_node = create_compatibility_agent(model_provider=model_provider)

    active_store = repair_store or DemoCacheStore()
    active_ledger = execution_ledger or ExecutionLedger()
    active_tools = dict(windows_tools or {})
    active_tools.setdefault(DEMO_TOOL_NAME, active_store.tool_result)
    active_evidence_node = evidence_collection_node or create_evidence_collection_node(
        retriever=retriever, windows_tools=active_tools
    )
    action_proposal_node = create_action_proposal_node(
        proposer=action_proposer,
        model_provider=model_provider,
    )
    ieee_verification_node = create_ieee_verification_node(
        assessor=ieee_assessor,
        model_provider=model_provider,
    )

    graph = StateGraph(OSGuardState)
    graph.add_node("supervisor", create_supervisor_node(active_classifier))
    graph.add_node("collect_evidence", active_evidence_node)
    graph.add_node("diagnostic_agent", diagnostic_node)
    graph.add_node("command_verification_agent", command_node)
    graph.add_node("compatibility_agent", compatibility_node)
    graph.add_node("aggregate_findings", aggregate_findings_node)
    graph.add_node("propose_corrective_actions", action_proposal_node)
    graph.add_node("ieee_verification", ieee_verification_node)
    planning_node = create_repair_planning_node(active_store)
    if checkpointer is None:
        def no_checkpoint_planning(state: OSGuardState) -> dict[str, Any]:
            update = planning_node(state)
            if update.get("repair_plan") is not None:
                plan = update["repair_plan"]
                update["approval_state"] = ApprovalState(
                    status="not_requested", action_id=plan.action_id, plan_id=plan.plan_id,
                    reason_codes=["checkpoint_unavailable"],
                )
                update["workflow_status"] = "approval_unavailable"
            return update
        graph.add_node("repair_planning", no_checkpoint_planning)
    else:
        graph.add_node("repair_planning", planning_node)
    graph.add_node("approval_interrupt", create_approval_node(active_store))
    graph.add_node("restricted_executor", create_restricted_executor_node(active_store, active_ledger))
    graph.add_node("post_repair_validation", create_post_repair_validation_node(active_store))
    graph.add_node("final_response", final_response_node)

    graph.add_edge(START, "supervisor")
    graph.add_edge("supervisor", "collect_evidence")
    graph.add_conditional_edges("collect_evidence", route_to_next_specialist)
    for node_name in _SPECIALIST_NODES.values():
        graph.add_conditional_edges(node_name, route_to_next_specialist)
    graph.add_edge("aggregate_findings", "propose_corrective_actions")
    graph.add_edge("propose_corrective_actions", "ieee_verification")
    graph.add_edge("ieee_verification", "repair_planning")
    def route_after_planning(state: OSGuardState) -> Literal["approval_interrupt", "final_response"]:
        return "approval_interrupt" if (
            checkpointer is not None
            and state.get("repair_plan") is not None
            and state.get("repair_eligibility") is not None
            and state["repair_eligibility"].status == "eligible"
        ) else "final_response"

    def route_after_approval(state: OSGuardState) -> Literal["restricted_executor", "final_response"]:
        return "restricted_executor" if (
            state.get("approval_state") is not None
            and state["approval_state"].status == "approved"
        ) else "final_response"

    graph.add_conditional_edges("repair_planning", route_after_planning)
    graph.add_conditional_edges("approval_interrupt", route_after_approval)
    graph.add_edge("restricted_executor", "post_repair_validation")
    graph.add_edge("post_repair_validation", "final_response")
    graph.add_edge("final_response", END)
    return graph.compile(checkpointer=checkpointer)
