# OSGuard AI Progress

## Current milestone: Phase 5 — controlled demo repair review and verification

**Status:** The existing Phase 5 implementation passed focused and full
automated verification on `.venv` CPython 3.14.8. This review found no
implementation defect requiring a code change. Phase 6 was not started.

### Implemented and reviewed

- LangGraph routes every proposed action through the IEEE node, deterministic
  eligibility, and exact repair planning. Only the registered
  `CLEAR_OSGUARD_DEMO_CACHE` action can reach the restricted executor.
- A checkpointed `interrupt()` pauses for a separate human decision. Resume
  requires the same thread, an affirmative decision, and the exact plan ID and
  SHA-256 fingerprint. The action, IEEE result, target, parameters, and current
  cache precondition are checked again after approval and before execution.
- The single handler truncates only the known OSGuard-owned disposable cache
  payload under `data/demo_app/cache`. It rejects unknown entries, altered
  fixture bytes, arbitrary targets, and detected symlinks/junctions/reparse
  points. No shell, PowerShell, privileged Windows repair, or arbitrary path
  execution is present in the repair registry.
- A process-local execution ledger claims a plan before the file change, so
  repeat submissions do not execute it twice. Fresh post-repair inspection
  checks the actual payload and ownership marker before reporting resolved,
  partially resolved, unresolved, failed, or unverifiable.
- Streamlit presents the exact plan and separate `APPROVE`/`DECLINE` controls
  only for an eligible pending checkpoint. It clears its resume cursor before
  submitting a decision. The demo fixture requires an explicit preparation
  action in the UI.

### Exact test results

- `.\.venv\Scripts\python.exe --version`: **Python 3.14.8**.
- `python -m pytest tests/test_phase5_repair.py -q --disable-warnings
  --log-disable=langgraph.checkpoint.serde.jsonplus`: **36 passed, 1 skipped,
  17 warnings** in 10.62 seconds.
- `python -m pytest tests/test_app_ui.py -q --disable-warnings
  --log-disable=langgraph.checkpoint.serde.jsonplus`: **7 passed, 17 warnings**
  in 3.38 seconds. This includes the two Phase 5 UI tests.
- One final full-suite run, `python -m pytest -q --disable-warnings
  --log-disable=langgraph.checkpoint.serde.jsonplus`: **139 passed, 1 skipped,
  17 warnings** in 12.57 seconds. The suite was run once after the focused
  review; no failures occurred.
- The single skip was the actual directory-symlink creation test on this
  Windows account: `WinError 1314` (required symlink privilege unavailable).
  Separate mocked junction and symlink guard tests passed. The 17 warnings
  are existing `langsmith` deprecation warnings; warning/log output was
  suppressed in the command but counted by pytest.

### What the tests establish

The isolated `tmp_path` fixture exercised real LangGraph interrupt/resume and
the registered Python handler, with an unrelated sibling file checked intact.
Tests covered missing or failed IEEE results, no approval, decline, stale or
changed plan approval, unregistered actions, modified parameters and arbitrary
paths, duplicate direct execution and graph resume, changed cache evidence,
permission failure, malformed agent output, partial specialist failure, and
fresh validation that refuses to claim success when the payload remains. The
default exact demo request was exercised without a Groq call or FAISS lookup.
Streamlit tests used a fake UI and graph; they verified the pending-plan controls
and one-time resume cursor, not a browser session.

### Limitations and manual Windows checks

- Native FAISS loading remains blocked by the previously observed Windows
  Application Control policy for `_swigfaiss`; no policy bypass was attempted.
  The full suite uses a FAISS test double where needed. This blocker is
  independent of the exact local demo-cache route.
- A real directory symlink guard needs a Windows account permitted to create
  that symlink. The guard's junction and payload-symlink branches passed with
  isolated mocked filesystem responses.
- No live Groq request, browser-based Streamlit approval session, live FAISS
  retrieval, host diagnostic sampling, or demo repair outside pytest temporary
  fixtures was performed during this review. Those need manual Windows checks
  before claiming a complete live demonstration.
- `InMemorySaver` and the execution ledger are process-local. Restarting the
  app loses a pending approval session; no persistent or multi-process
  execution guarantee is claimed. Only the OSGuard disposable demo cache is
  repairable. Other recommendations remain recommendation-only.

### Files modified in this review

- `README.md`, `docs/ARCHITECTURE.md`, and `docs/PROGRESS.md` were updated to
  describe the verified Phase 5 behavior and limitations. No implementation or
  test code was changed.

### Next phase

Phase 5 is ready for a manual Windows demonstration of the disposable fixture
once the remaining environment restrictions are handled. Phase 6 has not begun.

## Historical report: Phase 4 — IEEE verification framework

**Status:** Phase 4 implementation is complete. The focused Phase 4 tests
passed: **39 passed, 17 warnings** in 13.63 seconds. The final full-suite run
passed on CPython 3.14.8 (64-bit): **101 passed, 17 warnings** in 5.01 seconds.
No live Groq request, Windows inspection, or repair was performed.

### Implemented

- Added typed corrective-action candidates, evidence quotes, action proposals,
  per-action IEEE results, and explicit workflow summary states.
- Added a bounded structured-output proposal node and a structured IEEE
  assessment node. They reuse the graph's shared Groq model and support
  dependency injection for deterministic tests.
- Connected the required graph path from specialist aggregation through
  proposal and IEEE verification to the final response; there is no graph edge
  that skips the verification stage.
- Added deterministic intent, environment, evidence, effect, target, and action
  identity checks. A result is supported only when every check passes; missing
  facts remain uncertain and prohibited/unsupported operations fail closed.
- Kept proposals limited to evidence-backed dependency mismatches with an
  explicitly requested remediation. The graph does not execute commands,
  approve repairs, or modify Windows.
- Updated Streamlit to show proposals, source excerpts, four verification
  checks, unsupported/uncertain outcomes, and no-action/failure states without
  presenting approval or execution controls.
- Added focused unit, graph integration, and UI coverage using mocked models,
  specialists, evidence, and tools. No unit test needs a live Groq API call.

### Phase 4 files added or modified

- Added `src/osguard/verification/__init__.py`, `proposals.py`, `rules.py`,
  `ieee.py`, `tests/test_ieee_verification.py`, and
  `tests/test_phase4_graph.py`.
- Modified `src/osguard/schemas.py`, `src/osguard/state.py`,
  `src/osguard/graph.py`, `app.py`, `tests/test_app_ui.py`, `README.md`,
  `docs/ARCHITECTURE.md`, and this progress report.

### Phase 4 limitations

- Only documented dependency-version mismatches can currently produce
  candidate recommendations. Other repair classes remain unsupported.
- `supported` means the recommendation passed the evidence and policy checks;
  it does not mean the operation is eligible for execution or approved.
- Native FAISS loading remains blocked by the existing Windows Application
  Control policy, as recorded in the Phase 3 report below. It was not bypassed.
- No live Groq call, live corpus retrieval, host inspection, command execution,
  repair, or user approval was performed.

## Historical report: Phase 3 — FAISS RAG and read-only Windows tools

**Status:** Phase 3 implementation and mocked automated coverage are complete.
At the time Phase 3 was completed, the full suite passed on CPython 3.14.8
(64-bit): **66 passed, 17 warnings** in 4.71 seconds. `compileall` also
completed successfully. No Groq request, Windows inspection, documentation
download, or repair was performed.

### Implemented

- Added typed shared retrieval and tool-result state, including reducer-backed
  aggregation across the selected specialists.
- Added a curated Microsoft Learn source list, HTTPS/host validation, HTML
  cleaning, section-aware chunking, local Sentence Transformers embeddings,
  FAISS cosine search, source metadata, checksums, bounded results, exact
  metadata filters, and explicit missing/corrupt/error statuses.
- Added an index builder (`python -m osguard.rag.build_index`) that persists
  the generated index locally under gitignored `data/faiss/`. The application
  reuses a loaded index and does not rebuild it per request.
- Added six bounded read-only Windows checks: system information, process/CPU
  sampling, memory, disk capacity, exact-name service status, and filtered
  Application/System/Setup event logs. They do not invoke PowerShell, request
  elevation, or modify Windows.
- Added one shared evidence-collection node after Supervisor classification.
  It performs at most one retrieval and selects only fixed tools relevant to
  the classified problem. The three existing specialists receive the same
  evidence snapshot and validate claims against source IDs and quoted evidence.
- Updated Streamlit to display observed environment data, retrieval status and
  citations, tool statuses, findings, and partial failures without inventing
  evidence.
- Added deterministic RAG, Windows-tool, specialist, graph, and UI coverage.
  Tests inject fake embeddings/FAISS, tools, retrievers, and model outputs;
  they do not call Groq or inspect the host.

### Files added or modified

- Added `src/osguard/context.py`, `src/osguard/rag/` modules,
  `src/osguard/tools/windows.py`, `data/documentation_sources.json`,
  `tests/test_rag.py`, `tests/test_windows_tools.py`,
  `tests/test_phase3_agents.py`, and `tests/test_phase3_graph.py`.
- Modified `src/osguard/agents/`, `src/osguard/graph.py`,
  `src/osguard/schemas.py`, `src/osguard/state.py`, `app.py`,
  `tests/test_app_ui.py`, `tests/test_supervisor_graph.py`, `pyproject.toml`,
  `.gitignore`, `README.md`, and `docs/ARCHITECTURE.md`.

### Verification and remaining environment blocker

- `.venv` is CPython 3.14.8 x64. Direct imports of `pydantic_core` 2.50.5,
  `langchain_groq`, and `langgraph` succeeded. `sentence_transformers` 6.3.0
  and `psutil` 7.2.2 imported successfully.
- Direct `import faiss` failed while loading `_swigfaiss` with
  `ImportError: DLL load failed while importing _swigfaiss: An Application
  Control policy has blocked this file.` No security setting was bypassed or
  changed. The native index build/load and real retrieval path therefore remain
  unverified; tests use a deterministic FAISS test double.
- The corpus has not been fetched and the local embedding model has not been
  run. No live Groq request or Windows tool sampling was performed.
- Pytest reported 17 `langsmith` deprecation warnings for
  `asyncio.iscoroutinefunction`, slated for removal in Python 3.16; no test
  failures remained.

### Limitations at Phase 3 completion

The indexed evidence and read-only tools now flow through the existing graph,
but native FAISS runtime verification is still blocked by Windows Application
Control. IEEE verification was the next milestone at that point; it is now
implemented. Repair planning/approval/execution and post-repair validation
remain future work.

## Historical report: Phase 2 — Specialist Agents

The following section records Phase 2 results from before Phase 3 was started.

**Status:** Phase 2 specialist workflows and automated coverage are implemented.
The full pytest suite passed on `.venv` Python 3.14.8: 41 passed, with 17
dependency deprecation warnings. No live Groq request or OS command was used.
The historical Windows Application Control block on `pydantic_core` was not
encountered in this run; no security policy was bypassed or changed.

### Implemented in code

- Replaced all three placeholder specialists with reusable structured-output
  LangChain workflows backed by the existing Groq model factory.
- Changed graph construction to share one `ChatGroq` model instance among the
  Supervisor and selected specialists. Classifiers, model factories, models,
  and specialist node functions can be injected.
- Added prompt-boundary redaction for common Windows paths, account labels,
  email addresses, SIDs, and labeled IP addresses before user text is sent to
  Groq. Quote grounding and static command matching use the redacted text.
- Diagnostic Agent: extracts user-reported symptoms, potential subsystems,
  quote-grounded observations and hypotheses, missing information, uncertainty,
  and non-invasive information-gathering steps. It does not inspect the host;
  unsupported quotes and steps that appear to modify the system are omitted.
- Command Verification Agent: reviews supplied command text without running
  it, reports intent fit, recognized and unknown command names, possible
  effects, risk, and administrator uncertainty. Deterministic static rules flag
  known mutating commands and preserve unknown commands as unverified. The
  structured contract prohibits execution.
- Compatibility Agent: retains version and OS/architecture facts only when
  present in user input, distinguishes user-reported facts from hypotheses,
  and leaves the result unknown unless explicit versions and a comparison
  constraint can be checked.
- Added append reducers for specialist findings, missing information, and
  uncertainty. Specialist failures are recorded without dropping completed
  results from other agents; graph routing remains bounded to one invocation
  per selected specialist.
- Updated the final response and Streamlit UI to show agent status, diagnostic
  quotes and hypotheses, unperformed safe steps, command review, compatibility
  facts, missing information, uncertainty, and partial failures.
- Populated `docs/ARCHITECTURE.md` with the frozen architecture and current
  implementation boundaries. Updated README behavior and examples.

### Files added or modified

- Added: `src/osguard/agents/_common.py`.
- Added: `tests/test_app_ui.py` and `tests/test_specialist_agents.py`.
- Modified: `src/osguard/agents/diagnostic.py`,
  `src/osguard/agents/command_verify.py`,
  `src/osguard/agents/compatibility.py`, `src/osguard/graph.py`,
  `src/osguard/schemas.py`, `src/osguard/state.py`,
  `src/osguard/supervisor.py`, `app.py`, and
  `tests/test_supervisor_graph.py`.
- Updated: `README.md`, `docs/ARCHITECTURE.md`, and this report.

### Tests and live services

- Ran `.\.venv\Scripts\python.exe -m pytest -q`: **41 passed, 17 warnings** in
  5.38 seconds. The warnings are `langsmith` deprecations for
  `asyncio.iscoroutinefunction`; there were no test failures or blocked tests.
- Replaced Phase 1 placeholder assertions with Phase 2 routing and graph tests
  using injected specialist nodes. Coverage includes single and multiple
  routing, reducer-backed state preservation, partial failures, and invalid
  structured specialist output.
- Exercised the Supervisor through all three real specialist nodes using an
  injected deterministic structured-output model; this made no Groq request.
- Added deterministic tests for Diagnostic, Command Verification, and
  Compatibility agents, plus Streamlit result rendering for successful and
  failed specialist workflows.
- Every graph test injects its classifier and specialist nodes, or supplies a
  fake structured-output model. Tests do not require Groq credentials or send
  network requests. Groq client tests also use fake model factories.
- Pydantic model imports and validation succeeded during this run. The prior
  Application Control block was not reproduced; no policy changes or bypasses
  were attempted.
- No live Groq request, Streamlit server, Windows diagnostic, PowerShell
  command, or repair was run.

### Known limitations

- Runtime behavior is unverified. The previously observed Windows Application
  Control policy was not reproduced by this test run, but live app startup and
  a real Groq call were not tested.
- Specialist analysis is based on the request text only. There is no live
  Windows inspection, PowerShell parser, FAISS retrieval, vendor-document
  verification, or authoritative software inventory.
- Privacy redaction covers common patterns only; it cannot guarantee that all
  sensitive content in arbitrary logs is removed.
- Command recognition uses a small conservative static name policy, not a
  complete PowerShell grammar. Unknown or complex syntax remains unverified.
- Compatibility results remain unknown when explicit, comparable requirements
  are absent.
- The mandatory IEEE gate, repair plan, approval mechanism, restricted repair
  executor, and post-repair validation are not implemented yet.

### Next phase

Phase 3 is not started. Phase 2 is ready to proceed based on the full local
automated suite; live Groq behavior and browser-based Streamlit startup remain
unverified. Per the implementation guide, the next milestone is trusted
evidence retrieval and approved read-only Windows tools. The IEEE gate and
repair workflow remain later milestones.
